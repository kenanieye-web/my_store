from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages
from django.contrib.auth import login, logout, authenticate
from django.contrib.auth.models import User
from django.contrib.auth.decorators import login_required
from django.db.models import Q
from .models import Product, Category, Cart, CartItem, Order, OrderItem
from .forms import ProductForm

def home(request):
    """الواجهة الرئيسية للمتجر"""
    categories = Category.objects.all()[:4]
    latest_products = Product.objects.filter(is_available=True).order_by('-id')[:6]
    
    context = {
        'categories': categories,
        'latest_products': latest_products,
    }
    return render(request, 'shop/home.html', context)

def product_list(request):
    """عرض المنتجات مع دعم البحث والتصفية حسب القسم"""
    products = Product.objects.filter(is_available=True)
    categories = Category.objects.all()
    
    # البحث باسم المنتج
    search_query = request.GET.get('q')
    if search_query:
        products = products.filter(name__icontains=search_query)
        
    # الفلترة حسب التصنيف
    category_id = request.GET.get('category')
    if category_id:
        products = products.filter(category_id=category_id)
        
    context = {
        'products': products,
        'categories': categories,
        'selected_category': category_id,
        'search_query': search_query,
    }
    return render(request, 'shop/product_list.html', context)

def product_detail(request, pk):
    """عرض تفاصيل منتج محدد"""
    product = get_object_or_404(Product, pk=pk, is_available=True)
    return render(request, 'shop/product_detail.html', {'product': product})

def add_to_cart(request, product_id):
    """إضافة منتج إلى سلة التسوق"""
    product = get_object_or_404(Product, id=product_id)
    cart_id = request.session.get('cart_id')
    
    if not cart_id:
        cart = Cart.objects.create()
        request.session['cart_id'] = cart.id
    else:
        cart = Cart.objects.filter(id=cart_id).first()
        if not cart:
            cart = Cart.objects.create()
            request.session['cart_id'] = cart.id

    # قراءة الكمية المطلوبة إن وجدت (افتراضياً 1)
    try:
        quantity = int(request.POST.get('quantity', 1))
    except ValueError:
        quantity = 1

    cart_item, created = CartItem.objects.get_or_create(cart=cart, product=product)
    if not created:
        cart_item.quantity += quantity
        cart_item.save()
    else:
        cart_item.quantity = quantity
        cart_item.save()

    messages.success(request, f"تمت إضافة '{product.name}' إلى سلة التسوق بنجاح!")
    return redirect('cart_detail')

def cart_detail(request):
    """عرض محتويات سلة التسوق"""
    cart_id = request.session.get('cart_id')
    cart = None
    if cart_id:
        cart = Cart.objects.filter(id=cart_id).first()
    return render(request, 'shop/cart_detail.html', {'cart': cart})

# --- الدوال الخاصة بإدارة السلة ---

def remove_from_cart(request, item_id):
    """حذف عنصر محدد من السلة"""
    cart_item = get_object_or_404(CartItem, id=item_id)
    product_name = cart_item.product.name
    cart_item.delete()
    messages.info(request, f"تم حذف '{product_name}' من سلة التسوق.")
    return redirect('cart_detail')

def update_cart_quantity(request, item_id):
    """زيادة أو إنقاص كمية عنصر داخل السلة"""
    cart_item = get_object_or_404(CartItem, id=item_id)
    action = request.POST.get('action')
    
    if action == 'increase':
        cart_item.quantity += 1
        cart_item.save()
        messages.success(request, f"تم تحديث كمية '{cart_item.product.name}'.")
    elif action == 'decrease':
        if cart_item.quantity > 1:
            cart_item.quantity -= 1
            cart_item.save()
            messages.success(request, f"تم تحديث كمية '{cart_item.product.name}'.")
        else:
            product_name = cart_item.product.name
            cart_item.delete()
            messages.info(request, f"تم حذف '{product_name}' من سلة التسوق.")
            
    return redirect('cart_detail')

# ----------------------------------

def checkout(request):
    """صفحة إتمام الطلب الشراء"""
    cart_id = request.session.get('cart_id')
    cart = Cart.objects.filter(id=cart_id).first() if cart_id else None

    if not cart or not cart.items.exists():
        messages.warning(request, "سلة التسوق فارغة!")
        return redirect('product_list')

    total_price = sum((item.get_total_price() for item in cart.items.all()), 0)

    if request.method == 'POST':
        full_name = request.POST.get('full_name')
        city = request.POST.get('city')
        address = request.POST.get('address')
        phone = request.POST.get('phone')

        order = Order.objects.create(
            user=request.user if request.user.is_authenticated else None,
            full_name=full_name,
            city=city,
            address=address,
            phone=phone,
            total_price=total_price
        )

        for item in cart.items.all():
            OrderItem.objects.create(
                order=order,
                product=item.product,
                price=item.product.price,
                quantity=item.quantity
            )

        cart.delete()
        if 'cart_id' in request.session:
            del request.session['cart_id']

        messages.success(request, f"تم إتمام طلبك بنجاح! رقم الطلب #{order.id}")
        return render(request, 'shop/order_success.html', {'order': order})

    return render(request, 'shop/checkout.html', {'cart': cart, 'total_price': total_price})


# --- نظام تسجيل المستخدمين والحساب الشخصي ---

def register_user(request):
    """تسجيل حساب مستخدم جديد عبر البريد الإلكتروني والاسم الكامل بدون قيود معقدة"""
    if request.user.is_authenticated:
        return redirect('home')

    if request.method == 'POST':
        full_name = request.POST.get('full_name')
        email = request.POST.get('email')
        password = request.POST.get('password')

        if not email or not password or not full_name:
            messages.error(request, "يرجى ملء جميع الحقول المطلوبة.")
        elif User.objects.filter(username=email).exists():
            messages.error(request, "هذا البريد الإلكتروني مسجل مسبقاً.")
        else:
            user = User.objects.create_user(username=email, email=email, password=password, first_name=full_name)
            login(request, user)
            messages.success(request, f"أهلاً بك يا {full_name}! تم إنشاء حسابك بنجاح.")
            return redirect('home')

    return render(request, 'shop/register.html')

def login_user(request):
    """تسجيل الدخول باستخدام البريد الإلكتروني وكلمة المرور البسيطة"""
    if request.user.is_authenticated:
        return redirect('home')

    if request.method == 'POST':
        email = request.POST.get('email')
        password = request.POST.get('password')
        
        user = authenticate(request, username=email, password=password)
        if user is not None:
            login(request, user)
            messages.success(request, "مرحباً بك مجدداً!")
            return redirect('home')
        else:
            messages.error(request, "البريد الإلكتروني أو كلمة المرور غير صحيحة.")

    return render(request, 'shop/login.html')

def logout_user(request):
    """تسجيل الخروج"""
    logout(request)
    messages.info(request, "تم تسجيل الخروج بنجاح.")
    return redirect('home')

@login_required(login_url='login')
def customer_profile(request):
    """لوحة حساب الزبون لعرض طلباته السابقة ومتابعة حالتها الخاصة به فقط"""
    orders = Order.objects.filter(user=request.user).order_by('-created_at')
    return render(request, 'shop/customer_profile.html', {'orders': orders})


# --- لوحة تحكم التاجر (محمية حصرياً للمشرفين والتاجر) ---

@login_required(login_url='login')
def merchant_dashboard(request):
    """لوحة التحكم الخاصة بالتاجر والإحصائيات"""
    if not request.user.is_staff:
        messages.error(request, "عذراً، هذه الصفحة خاصة بالتاجر فقط.")
        return redirect('customer_profile')

    new_orders_count = Order.objects.filter(Q(status='new') | Q(status='جديد')).count()
    shipping_orders_count = Order.objects.filter(Q(status='shipping') | Q(status='قيد الشحن') | Q(status='جاري الشحن') | Q(status='التوصيل')).count()
    delivered_orders_count = Order.objects.filter(Q(status='delivered') | Q(status='تم التوصيل')).count()
    canceled_orders_count = Order.objects.filter(Q(status='canceled') | Q(status='ملغي') | Q(status='الملغية')).count()

    recent_orders = Order.objects.all().order_by('-created_at')[:5]

    context = {
        'new_orders_count': new_orders_count,
        'shipping_orders_count': shipping_orders_count,
        'delivered_orders_count': delivered_orders_count,
        'canceled_orders_count': canceled_orders_count,
        'recent_orders': recent_orders,
    }
    return render(request, 'shop/dashboard.html', context)

# --- إدارة الطلبات للتاجر (محمية أيضاً) ---

@login_required(login_url='login')
def order_list(request):
    """عرض قائمة جميع الطلبات المسجلة"""
    if not request.user.is_staff:
        messages.error(request, "عذراً، هذه الصفحة خاصة بالتاجر فقط.")
        return redirect('customer_profile')

    orders = Order.objects.all().order_by('-created_at')
    return render(request, 'shop/order_list.html', {'orders': orders})

@login_required(login_url='login')
def order_detail(request, pk):
    """عرض تفاصيل طلب محدد وتحديث حالته"""
    if not request.user.is_staff:
        messages.error(request, "عذراً، هذه الصفحة خاصة بالتاجر فقط.")
        return redirect('customer_profile')

    order = get_object_or_404(Order, pk=pk)
    
    if request.method == 'POST':
        new_status = request.POST.get('status')
        if new_status:
            order.status = new_status
            order.save()
            messages.success(request, f"تم تحديث حالة الطلب #{order.id} بنجاح.")
            return redirect('order_detail', pk=order.id)

    return render(request, 'shop/order_detail.html', {'order': order})


# --- إدارة المنتجات للتاجر (إضافة، تعديل، حذف) ---

@login_required(login_url='login')
def merchant_product_list(request):
    """عرض قائمة منتجات المتجر للتاجر لإدارتها"""
    if not request.user.is_staff:
        messages.error(request, "عذراً، هذه الصفحة خاصة بالتاجر فقط.")
        return redirect('customer_profile')
    
    products = Product.objects.all().order_by('-id')
    return render(request, 'shop/merchant_product_list.html', {'products': products})

@login_required(login_url='login')
def add_product(request):
    """إضافة منتج جديد بواسطة التاجر"""
    if not request.user.is_staff:
        messages.error(request, "عذراً، هذه الصفحة خاصة بالتاجر فقط.")
        return redirect('customer_profile')
    
    if request.method == 'POST':
        form = ProductForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            messages.success(request, "تم إضافة المنتج بنجاح!")
            return redirect('merchant_product_list')
    else:
        form = ProductForm()
    
    return render(request, 'shop/add_product.html', {'form': form})

@login_required(login_url='login')
def edit_product(request, pk):
    """تعديل منتج موجود"""
    if not request.user.is_staff:
        messages.error(request, "عذراً، هذه الصفحة خاصة بالتاجر فقط.")
        return redirect('customer_profile')
    
    product = get_object_or_404(Product, pk=pk)
    if request.method == 'POST':
        form = ProductForm(request.POST, request.FILES, instance=product)
        if form.is_valid():
            form.save()
            messages.success(request, f"تم تحديث المنتج '{product.name}' بنجاح!")
            return redirect('merchant_product_list')
    else:
        form = ProductForm(instance=product)
        
    return render(request, 'shop/edit_product.html', {'form': form, 'product': product})

@login_required(login_url='login')
def delete_product(request, pk):
    """حذف منتج"""
    if not request.user.is_staff:
        messages.error(request, "عذراً، هذه الصفحة خاصة بالتاجر فقط.")
        return redirect('customer_profile')
    
    product = get_object_or_404(Product, pk=pk)
    product_name = product.name
    product.delete()
    messages.success(request, f"تم حذف المنتج '{product_name}' بنجاح.")
    return redirect('merchant_product_list')